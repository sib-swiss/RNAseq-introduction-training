#!/bin/bash
#SBATCH --job-name=trim
#SBATCH --time=01:00:00
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=1G
#SBATCH -o trim.o
#SBATCH -e trim.e


ml trimmomatic

dataDIR=/shared/data/DATA/Liu2015

trimmomatic="java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar"

outDIR=TRIM

mkdir -p $outDIR

$trimmomatic PE -threads 4 -phred33 \
             $dataDIR/SRR1272187_1.fastq.gz \
             $dataDIR/SRR1272187_2.fastq.gz \
             $outDIR/SRR1272187_NFLV_trimmed_paired_1.fastq $outDIR/SRR1272187_NFLV_trimmed_unpaired_1.fastq \
             $outDIR/SRR1272187_NFLV_trimmed_paired_2.fastq $outDIR/SRR1272187_NFLV_trimmed_unpaired_2.fastq \
             SLIDINGWINDOW:4:20 MINLEN:36 ILLUMINACLIP:/shared/data/DATA/adapters/TruSeq3-PE.fa:2:30:10 

gzip $outDIR/SRR1272187_NFLV_trimmed_paired_1.fastq
gzip $outDIR/SRR1272187_NFLV_trimmed_unpaired_1.fastq
gzip $outDIR/SRR1272187_NFLV_trimmed_paired_2.fastq
gzip $outDIR/SRR1272187_NFLV_trimmed_unpaired_2.fastq




