#!/usr/bin/bash
#SBATCH --job-name=multiqc_Liu2015
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc_Liu2015.o

multiqc -f 020_multiqc_Liu2015.html /shared/data/Solutions/Liu2015/010_fastqc/