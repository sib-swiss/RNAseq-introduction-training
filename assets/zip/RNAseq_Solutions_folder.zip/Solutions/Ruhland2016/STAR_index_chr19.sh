#!/usr/bin/bash
#SBATCH --job-name=star-build
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=3G
#SBATCH -o star-build.o
#SBATCH -e star-build.e

ml star

G_FASTA=/shared/data/DATA/Mouse_chr19/Mus_musculus.GRCm38.dna.chromosome.19.fa
G_GTF=/shared/data/DATA/Mouse_chr19/Mus_musculus.GRCm38.101.chr19.gtf

mkdir -p STAR_references

STAR --runMode genomeGenerate \
     --genomeDir STAR_references \
     --genomeFastaFiles $G_FASTA \
     --sjdbGTFfile $G_GTF \
     --outTmpDir /tmp/${SLURM_JOB_USER}_${SLURM_JOB_ID} \
     --runThreadN 4

