#!/usr/bin/bash
#SBATCH --job-name=multiqc_Ruhland2016
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc_Ruhland2016.o

multiqc -f 020_multiqc_Ruhland2016.html /shared/data/Solutions/Ruhland/010_fastqc/