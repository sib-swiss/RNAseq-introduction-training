#!/usr/bin/bash
#SBATCH --job-name=htseq
#SBATCH --time=02:30:00
#SBATCH --qos=6hours
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH -o htseq-count.%a.o
#SBATCH -e htseq-count.%a.e
#SBATCH --array 1-6%6

singularity_container=[DATA_FOLDER]/RNASEQ20.img
singularity_exec="singularity exec -B [DATA_FOLDER]/ $singularity_container"

sourceFILE=Ruhland2016.fastqFiles.txt
fastqFILE=`sed -n ${SLURM_ARRAY_TASK_ID}p $sourceFILE`

G_GTF=[DATA_FOLDER]/Mus_musculus.GRCm38.99.gtf

inFOLDER=${HOME}/Ruhland2016/STAR_Ruhland2016
outFOLDER=${HOME}/Ruhland2016/HTSQCOUNT_Ruhland2016

mkdir -p $outFOLDER

$singularity_exec htseq-count -f bam -s no -o $outFOLDER/$fastqFILE.hseq-count.report $inFOLDER/${fastqFILE}Aligned.sortedByCoord.out.bam $G_GTF > $outFOLDER/$fastqFILE.hseq-count.counts.txt

