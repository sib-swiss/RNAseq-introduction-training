#!/usr/bin/bash
#SBATCH --job-name=fc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH -o fc-count.%a.o
#SBATCH -e fc-count.%a.e


G_GTF=/shared/data/DATA/Mus_musculus.GRCm39.103.gtf

inFOLDER=STAR_Ruhland2016
outFOLDER=FEATURECOUNT_Ruhland2016

ml subread
mkdir -p $outFOLDER

featureCounts -T 8 -a $G_GTF -t exon -g gene_id -o $outFolder/featureCounts_Ruhland2016.counts.txt \
                                    $inFOLDER/SRR3180535_EtOH1_1.fastq.gzAligned.sortedByCoord.out.bam

