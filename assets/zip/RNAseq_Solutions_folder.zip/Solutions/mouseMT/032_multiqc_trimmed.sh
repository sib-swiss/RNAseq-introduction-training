#!/usr/bin/bash

## fastQC on trimmed fastq files
fastqc 030_trim/*.fastq -o 030_trim


## multiqc on the fastQC reports AND the trimmomatic logs
multiqc -n 032_multiqc_mouseMT_trimmed.html -f --title trimmed_fastq 030_trim/
