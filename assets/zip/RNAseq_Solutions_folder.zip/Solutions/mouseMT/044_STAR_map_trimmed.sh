#!/usr/bin/bash
#SBATCH --job-name=star-aln
#SBATCH --time=00:10:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=1G
#SBATCH -o star-aln.trimmed.%a.o
#SBATCH --array 1-8%8

ml star

mkdir -p 044_STAR_map_trimmed

SAMPLE=`sed -n ${SLURM_ARRAY_TASK_ID}p sampleNames.txt`

FASTQ_NAME=030_trim/${sampleName}.trimmed.fastq

STAR --runThreadN 4 --genomeDir 041_STAR_reference/ \
                 --outSAMtype BAM SortedByCoordinate \
                 --outFileNamePrefix  044_STAR_map_trimmed/${SAMPLE}_trimmed. \
                 --quantMode GeneCounts \
                 --readFilesIn $FASTQ_NAME
