#!/usr/bin/bash
#SBATCH --job-name=star-aln
#SBATCH --time=00:10:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=1G
#SBATCH -o star-aln.raw.%a.o
#SBATCH --array 1-8%8

ml star

mkdir -p 042_STAR_map_raw

SAMPLE=`sed -n ${SLURM_ARRAY_TASK_ID}p sampleNames.txt`

FASTQ_NAME=/shared/data/DATA/mouseMT/${sampleName}.fastq

STAR --runThreadN 4 --genomeDir 041_STAR_reference/ \
                 --outSAMtype BAM SortedByCoordinate \
                 --outFileNamePrefix  042_STAR_map_raw/${SAMPLE}. \
                 --quantMode GeneCounts \
                 --readFilesIn $FASTQ_NAME
