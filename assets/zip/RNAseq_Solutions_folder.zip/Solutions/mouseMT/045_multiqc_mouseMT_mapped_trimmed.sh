#!/usr/bin/bash
#SBATCH --job-name=map-multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc-map-raw.o

multiqc -n 045_multiqc_mouseMT_mapped_trimmed.html -f --title mapped_trimmed 044_STAR_map_trimmed/