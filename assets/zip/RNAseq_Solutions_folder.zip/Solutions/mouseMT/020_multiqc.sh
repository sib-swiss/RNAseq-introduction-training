#!/usr/bin/bash
#SBATCH --job-name=multiqc
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH -o multiqc_mouseMT.o

multiqc -f 020_multiqc_mouseMT.html 010_fastqc/ 
